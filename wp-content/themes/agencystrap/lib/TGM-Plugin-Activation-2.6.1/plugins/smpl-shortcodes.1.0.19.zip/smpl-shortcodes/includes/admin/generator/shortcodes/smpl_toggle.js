smplShortcodeAtts={
	attributes:[
		{
			label:"Title",
			id:"title",
			help:"Enter the title of the toggle."
		}
	],
	defaultContent:"Your content goes here.",
	shortcode:"toggle"
};